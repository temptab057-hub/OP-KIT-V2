# OPKITS V2 — Paper Plugin

Commands: `/kit`, `/rankshop`, `/kit customise`, `/rankshop customise`. Customizer access is OP-only.

## OP customizer commands
- `/kit customise default <kit|off>` — set or disable the automatic first-join kit.
- `/kit customise kitname <id> <name>` — rename a kit.
- `/kit customise kititem <id> <MATERIAL:AMOUNT>` — append an item to a kit.
- `/kit customise kitremove <id>` — remove a kit.
- `/rankshop customise rankname <id> <name>` — rename a rank.
- `/rankshop customise rankprice <id> <price>` — change a rank price.
- `/rankshop customise rankremove <id>` — remove a rank.

All changes save in `plugins/OPKITS/config.yml`. Edit that file to add new kit/rank sections, change icons, slots, permissions, lore, cooldowns, groups and purchase commands. Back up config.yml before editing.

New players receive the configured `first-join.default-kit` once. The default is `starter`; change it or set it to an empty string to disable.

Requirements: Paper 1.21.4, Java 21, Vault and an economy provider for rank purchases. LuckPerms is recommended. Build output: `build/libs/realfile.jar`.

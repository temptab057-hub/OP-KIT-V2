package me.nubayt.kits;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class NubaytKits extends JavaPlugin implements Listener, CommandExecutor {

    private NamespacedKey kitKey;
    private NamespacedKey rankKey;
    private NamespacedKey adminKey;
    private Economy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        kitKey = new NamespacedKey(this, "kit_id");
        rankKey = new NamespacedKey(this, "rank_id");
        adminKey = new NamespacedKey(this, "admin_customizer");
        setupEconomy();

        if (getCommand("kit") != null) getCommand("kit").setExecutor(this);
        if (getCommand("rankshop") != null) getCommand("rankshop").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("OPKITS v1 enabled!");
    }

    private void setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            getLogger().warning("Vault not found. /rankshop will show an economy unavailable message.");
            return;
        }
        RegisteredServiceProvider<Economy> provider =
                Bukkit.getServicesManager().getRegistration(Economy.class);
        if (provider != null) economy = provider.getProvider();
        if (economy == null) getLogger().warning("No Vault economy provider found. Install an economy plugin.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("customise")) {
            if (!(sender instanceof Player admin) || !admin.isOp()) {
                sender.sendMessage(color("&cOnly server operators can use the customizer."));
                return true;
            }
            if (args.length == 1) {
                showCustomizer(admin);
                return true;
            }
            customize(admin, args);
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used in-game.");
            return true;
        }
        if (command.getName().equalsIgnoreCase("rankshop")) openRankShop(player);
        else openKitMenu(player);
        return true;
    }

    private void showCustomizer(Player player) {
        player.sendMessage(color("&6&lOPKITS V2 CUSTOMIZER &7(OP only)"));
        player.sendMessage(color("&e/kit customise default <kit|off> &7- choose first-join kit"));
        player.sendMessage(color("&e/kit customise kitname <id> <name> &7- rename a kit"));
        player.sendMessage(color("&e/kit customise kititem <id> <MATERIAL:AMOUNT> &7- add kit item"));
        player.sendMessage(color("&e/kit customise kitremove <id> &7- remove a kit"));
        player.sendMessage(color("&e/rankshop customise rankname <id> <name> &7- rename rank"));
        player.sendMessage(color("&e/rankshop customise rankprice <id> <price> &7- change price"));
        player.sendMessage(color("&e/rankshop customise rankremove <id> &7- remove rank"));
        player.sendMessage(color("&7Changes save automatically in plugins/OPKITS/config.yml"));
    }

    private void customize(Player player, String[] args) {
        if (args.length < 3) { showCustomizer(player); return; }
        String action = args[1].toLowerCase(Locale.ROOT);
        String id = args[2].toLowerCase(Locale.ROOT);
        String path;
        try {
            switch (action) {
                case "default" -> {
                    if (id.equals("off")) getConfig().set("first-join.default-kit", "");
                    else if (!getConfig().contains("kits." + id)) { player.sendMessage(color("&cKit not found.")); return; }
                    else getConfig().set("first-join.default-kit", id);
                    saveConfig(); player.sendMessage(color("&aDefault first-join kit updated."));
                }
                case "kitname" -> {
                    if (args.length < 4 || !getConfig().contains("kits." + id)) { player.sendMessage(color("&cUsage: /kit customise kitname <id> <name>")); return; }
                    getConfig().set("kits." + id + ".display-name", String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length)));
                    saveConfig(); player.sendMessage(color("&aKit name updated."));
                }
                case "kititem" -> {
                    if (args.length < 4 || !getConfig().contains("kits." + id)) { player.sendMessage(color("&cUsage: /kit customise kititem <id> <MATERIAL:AMOUNT>")); return; }
                    String spec = args[3].toUpperCase(Locale.ROOT);
                    String materialName = spec.split(":")[0];
                    if (Material.matchMaterial(materialName) == null) { player.sendMessage(color("&cUnknown material.")); return; }
                    List<String> items = getConfig().getStringList("kits." + id + ".items"); items.add(spec);
                    getConfig().set("kits." + id + ".items", items); saveConfig(); player.sendMessage(color("&aItem added to kit."));
                }
                case "kitremove" -> {
                    if (!getConfig().contains("kits." + id)) { player.sendMessage(color("&cKit not found.")); return; }
                    getConfig().set("kits." + id, null); if (id.equals(getConfig().getString("first-join.default-kit"))) getConfig().set("first-join.default-kit", "");
                    saveConfig(); player.sendMessage(color("&aKit removed."));
                }
                case "rankname" -> {
                    if (args.length < 4 || !getConfig().contains("rankshop.ranks." + id)) { player.sendMessage(color("&cUsage: /rankshop customise rankname <id> <name>")); return; }
                    getConfig().set("rankshop.ranks." + id + ".display-name", String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length)));
                    saveConfig(); player.sendMessage(color("&aRank name updated."));
                }
                case "rankprice" -> {
                    if (args.length < 4 || !getConfig().contains("rankshop.ranks." + id)) { player.sendMessage(color("&cUsage: /rankshop customise rankprice <id> <price>")); return; }
                    double price = Double.parseDouble(args[3]); if (price < 0 || !Double.isFinite(price)) throw new NumberFormatException();
                    getConfig().set("rankshop.ranks." + id + ".price", price); saveConfig(); player.sendMessage(color("&aRank price updated."));
                }
                case "rankremove" -> {
                    if (!getConfig().contains("rankshop.ranks." + id)) { player.sendMessage(color("&cRank not found.")); return; }
                    getConfig().set("rankshop.ranks." + id, null); saveConfig(); player.sendMessage(color("&aRank removed."));
                }
                default -> showCustomizer(player);
            }
        } catch (NumberFormatException ex) { player.sendMessage(color("&cInvalid number.")); }
    }

    @EventHandler
    public void onFirstJoin(org.bukkit.event.player.PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String kit = getConfig().getString("first-join.default-kit", "starter");
        if (kit == null || kit.isBlank() || getConfig().getBoolean("first-join.received." + player.getUniqueId(), false)) return;
        List<?> entries = getConfig().getList("kits." + kit + ".items");
        if (entries == null || entries.isEmpty()) return;
        List<ItemStack> rewards = new ArrayList<>();
        for (Object entry : entries) if (entry instanceof String spec) {
            String[] parts = spec.split(":"); Material material = Material.matchMaterial(parts[0].trim().toUpperCase(Locale.ROOT));
            if (material == null || material.isAir()) continue;
            int amount = 1; if (parts.length > 1) try { amount = Integer.parseInt(parts[1]); } catch (NumberFormatException ignored) {}
            while (amount > 0) { int stack = Math.min(amount, material.getMaxStackSize()); rewards.add(new ItemStack(material, stack)); amount -= stack; }
        }
        if (rewards.isEmpty()) return;
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(rewards.toArray(new ItemStack[0]));
        for (ItemStack item : leftovers.values()) player.getWorld().dropItemNaturally(player.getLocation(), item);
        getConfig().set("first-join.received." + player.getUniqueId(), true); saveConfig();
        player.sendMessage(color(getConfig().getString("first-join.message", "&aYou have received the Starter Kit!")));
    }

    private void openKitMenu(Player player) {
        KitMenuHolder holder = new KitMenuHolder();
        Inventory inventory = Bukkit.createInventory(holder, 45, color("&8✦ &6&lOP &e&lKITS &8✦"));
        holder.inventory = inventory;
        fillFrame(inventory);

        if (getConfig().isConfigurationSection("kits")) {
            for (String kitName : getConfig().getConfigurationSection("kits").getKeys(false)) {
                String path = "kits." + kitName + ".";
                int slot = getConfig().getInt(path + "slot", -1);
                if (slot < 0 || slot >= inventory.getSize() || isFrameSlot(slot)) continue;

                String permission = getConfig().getString(path + "permission", "");
                boolean unlocked = permission == null || permission.isBlank() || player.hasPermission(permission);
                long remaining = getRemainingCooldown(player.getUniqueId(), kitName);
                Material icon = unlocked ? Material.matchMaterial(getConfig().getString(path + "icon", "CHEST")) : Material.BARRIER;
                if (icon == null || icon.isAir()) icon = Material.CHEST;

                ItemStack display = new ItemStack(icon);
                ItemMeta meta = display.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName(color(getConfig().getString(path + "display-name", kitName)));
                    List<String> lore = new ArrayList<>();
                    for (String line : getConfig().getStringList(path + "lore")) lore.add(color(line));
                    lore.add(" ");
                    if (!unlocked) {
                        lore.add(color("&c&lLOCKED"));
                        lore.add(color("&7Required: &f" + permission));
                    } else if (remaining > 0) {
                        lore.add(color("&e&lCOOLDOWN"));
                        lore.add(color("&7Ready in: &f" + formatTime(remaining)));
                    } else {
                        lore.add(color("&a&l✔ READY TO CLAIM"));
                        lore.add(color("&e➜ Click to receive this kit"));
                    }
                    meta.setLore(lore);
                    meta.getPersistentDataContainer().set(kitKey, PersistentDataType.STRING, kitName);
                    display.setItemMeta(meta);
                }
                inventory.setItem(slot, display);
            }
        }
        inventory.setItem(22, namedItem(Material.NETHER_STAR, "&6&l✦ &e&lYOUR KIT MENU &6&l✦",
                "&7Choose a kit to claim.", "&8 ", "&a✔ &7Unlocked kits can be claimed",
                "&c✖ &7Locked kits require a rank", "&e⌛ &7Cooldowns are shown on each kit"));
        if (player.isOp()) { ItemStack admin = namedItem(Material.COMPARATOR, "&c&lCUSTOMIZER", "&7Open OPKITS settings"); ItemMeta am = admin.getItemMeta(); am.getPersistentDataContainer().set(adminKey, PersistentDataType.BYTE, (byte) 1); admin.setItemMeta(am); inventory.setItem(40, admin); }
        player.openInventory(inventory);
    }

    private void openRankShop(Player player) {
        if (economy == null) {
            player.sendMessage(color(getConfig().getString("rankshop.no-economy-message",
                    "&cEconomy is unavailable. Please contact an administrator.")));
            return;
        }
        int rows = Math.max(1, Math.min(6, getConfig().getInt("rankshop.rows", 3)));
        RankShopHolder holder = new RankShopHolder();
        Inventory inventory = Bukkit.createInventory(holder, rows * 9,
                color(getConfig().getString("rankshop.title", "&8✦ &6&lRANK SHOP &8✦")));
        holder.inventory = inventory;
        fillFrame(inventory);

        if (getConfig().isConfigurationSection("rankshop.ranks")) {
            for (String rankId : getConfig().getConfigurationSection("rankshop.ranks").getKeys(false)) {
                String path = "rankshop.ranks." + rankId + ".";
                int slot = getConfig().getInt(path + "slot", -1);
                if (slot < 0 || slot >= inventory.getSize() || isFrameSlot(slot)) continue;
                Material icon = Material.matchMaterial(getConfig().getString(path + "icon", "EMERALD"));
                if (icon == null || icon.isAir()) icon = Material.EMERALD;

                double price = getConfig().getDouble(path + "price", 0);
                String rankName = getConfig().getString(path + "display-name", rankId);
                ItemStack item = new ItemStack(icon);
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName(color(rankName));
                    List<String> lore = new ArrayList<>();
                    for (String line : getConfig().getStringList(path + "lore")) lore.add(color(line));
                    lore.add(" ");
                    lore.add(color("&6Price: &e" + formatMoney(price)));
                    lore.add(color("&7Your balance: &f" + formatMoney(economy.getBalance(player))));
                    lore.add(" ");
                    lore.add(color("&a➜ Click to purchase"));
                    meta.setLore(lore);
                    meta.getPersistentDataContainer().set(rankKey, PersistentDataType.STRING, rankId);
                    item.setItemMeta(meta);
                }
                inventory.setItem(slot, item);
            }
        }
        inventory.setItem(inventory.getSize() - 5, namedItem(Material.GOLD_INGOT, "&6&lYOUR BALANCE",
                "&7Money: &e" + formatMoney(economy.getBalance(player)),
                "&8Use your money to upgrade your rank."));
        if (player.isOp()) { ItemStack admin = namedItem(Material.COMPARATOR, "&c&lCUSTOMIZER", "&7Open OPKITS settings"); ItemMeta am = admin.getItemMeta(); am.getPersistentDataContainer().set(adminKey, PersistentDataType.BYTE, (byte) 1); admin.setItemMeta(am); inventory.setItem(inventory.getSize() - 6, admin); }
        player.openInventory(inventory);
    }

    private void fillFrame(Inventory inventory) {
        ItemStack frame = namedItem(Material.BLACK_STAINED_GLASS_PANE, "&8");
        ItemStack gold = namedItem(Material.YELLOW_STAINED_GLASS_PANE, "&6");
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            if (isFrameSlot(slot)) inventory.setItem(slot, frame);
        }
        inventory.setItem(0, gold);
        inventory.setItem(8, gold);
        inventory.setItem(inventory.getSize() - 9, gold);
        inventory.setItem(inventory.getSize() - 1, gold);
    }

    private boolean isFrameSlot(int slot) {
        int rows = slot / 9;
        int col = slot % 9;
        int totalRows = 5;
        return rows == 0 || rows == totalRows - 1 || col == 0 || col == 8;
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof KitMenuHolder) && !(top.getHolder() instanceof RankShopHolder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= top.getSize()) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        if (player.isOp() && clicked.getItemMeta().getPersistentDataContainer().has(adminKey, PersistentDataType.BYTE)) { showCustomizer(player); return; }

        if (top.getHolder() instanceof KitMenuHolder) {
            String kitName = clicked.getItemMeta().getPersistentDataContainer().get(kitKey, PersistentDataType.STRING);
            if (kitName != null) claimKit(player, kitName);
        } else {
            String rankId = clicked.getItemMeta().getPersistentDataContainer().get(rankKey, PersistentDataType.STRING);
            if (rankId != null) purchaseRank(player, rankId);
        }
    }

    private void claimKit(Player player, String kitName) {
        String path = "kits." + kitName + ".";
        String permission = getConfig().getString(path + "permission", "");
        if (permission != null && !permission.isBlank() && !player.hasPermission(permission)) {
            sendMessage(player, "messages.no-permission", "&cYou don't have permission to claim that kit.");
            return;
        }
        long remaining = getRemainingCooldown(player.getUniqueId(), kitName);
        if (remaining > 0) {
            player.sendMessage(color(getConfig().getString("messages.cooldown",
                    "&cYou can claim this kit again in &e%time%&c.").replace("%time%", formatTime(remaining))));
            return;
        }

        List<?> configuredItems = getConfig().getList(path + "items");
        if (configuredItems == null || configuredItems.isEmpty()) {
            player.sendMessage(color("&cThis kit has no items configured."));
            return;
        }
        List<ItemStack> rewards = new ArrayList<>();
        for (Object entry : configuredItems) {
            if (!(entry instanceof String itemSpec)) continue;
            String[] parts = itemSpec.split(":");
            Material material = Material.matchMaterial(parts[0].trim().toUpperCase(Locale.ROOT));
            if (material == null || material.isAir()) continue;
            int amount = 1;
            if (parts.length > 1) {
                try { amount = Integer.parseInt(parts[1].trim()); }
                catch (NumberFormatException ignored) { amount = 1; }
            }
            while (amount > 0) {
                int stack = Math.min(amount, material.getMaxStackSize());
                rewards.add(new ItemStack(material, stack));
                amount -= stack;
            }
        }
        if (rewards.isEmpty()) {
            player.sendMessage(color("&cThis kit has no valid items configured."));
            return;
        }
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(rewards.toArray(new ItemStack[0]));
        for (ItemStack item : leftovers.values()) player.getWorld().dropItemNaturally(player.getLocation(), item);

        long cooldown = Math.max(0, getConfig().getLong(path + "cooldown-seconds", 0));
        if (cooldown > 0) {
            getConfig().set("cooldowns." + player.getUniqueId() + "." + kitName,
                    System.currentTimeMillis() + cooldown * 1000L);
            saveConfig();
        }
        String displayName = getConfig().getString(path + "display-name", kitName);
        player.sendMessage(color(getConfig().getString("messages.claimed", "&aYou claimed the &e%kit% &akit!")
                .replace("%kit%", ChatColor.stripColor(color(displayName)))));
        player.closeInventory();
    }

    private void purchaseRank(Player player, String rankId) {
        if (economy == null) {
            player.sendMessage(color(getConfig().getString("rankshop.no-economy-message",
                    "&cEconomy is unavailable. Please contact an administrator.")));
            return;
        }
        String path = "rankshop.ranks." + rankId + ".";
        if (!getConfig().contains(path + "price")) return;
        double price = getConfig().getDouble(path + "price");
        String group = getConfig().getString(path + "group", rankId);
        String rankName = getConfig().getString(path + "display-name", rankId);

        if (group == null || group.isBlank()) {
            player.sendMessage(color("&cThis rank is not configured correctly. Contact an administrator."));
            return;
        }
        if (player.hasPermission("nubaytkits.rank." + group)) {
            player.sendMessage(color(getConfig().getString("rankshop.already-owned", "&eYou already have this rank.")));
            return;
        }
        double balance = economy.getBalance(player);
        if (balance < price) {
            String message = getConfig().getString("rankshop.not-enough-money",
                    "&cYou need &e%cost% &cto buy this rank. You have &e%balance%&c.")
                    .replace("%cost%", formatMoney(price)).replace("%balance%", formatMoney(balance));
            player.sendMessage(color(message));
            return;
        }

        var response = economy.withdrawPlayer(player, price);
        if (!response.transactionSuccess()) {
            player.sendMessage(color("&cPayment failed. Please try again or contact an administrator."));
            return;
        }

        List<String> commands = getConfig().getStringList("rankshop.purchase-commands");
        if (commands.isEmpty()) {
            economy.depositPlayer(player, price);
            player.sendMessage(color("&cRank purchase commands are not configured. Your money was refunded."));
            getLogger().warning("Rank shop purchase-commands is empty; refunded " + player.getName());
            return;
        }
        for (String command : commands) {
            String rendered = command.replace("%player%", player.getName())
                    .replace("%uuid%", player.getUniqueId().toString())
                    .replace("%group%", group)
                    .replace("%rank%", rankId);
            boolean success = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), rendered);
            if (!success) {
                getLogger().warning("Rank command returned false for " + player.getName() + ": " + rendered);
            }
        }

        String message = getConfig().getString("rankshop.purchased",
                "&aYou purchased &e%rank% &afor &6%cost%&a!")
                .replace("%rank%", ChatColor.stripColor(color(rankName)))
                .replace("%cost%", formatMoney(price));
        player.sendMessage(color(message));
        player.closeInventory();
    }

    private ItemStack namedItem(Material material, String name, String... loreLines) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            List<String> lore = new ArrayList<>();
            for (String line : loreLines) lore.add(color(line));
            if (!lore.isEmpty()) meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private long getRemainingCooldown(UUID uuid, String kitName) {
        long readyAt = getConfig().getLong("cooldowns." + uuid + "." + kitName, 0L);
        return Math.max(0L, (readyAt - System.currentTimeMillis() + 999L) / 1000L);
    }

    private String formatTime(long seconds) {
        long hours = seconds / 3600, minutes = (seconds % 3600) / 60, secs = seconds % 60;
        if (hours > 0) return hours + "h " + minutes + "m";
        if (minutes > 0) return minutes + "m " + secs + "s";
        return secs + "s";
    }

    private String formatMoney(double amount) {
        return new DecimalFormat("#,##0.##").format(amount);
    }

    private void sendMessage(Player player, String path, String fallback) {
        player.sendMessage(color(getConfig().getString(path, fallback)));
    }

    private String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input == null ? "" : input);
    }

    private static final class KitMenuHolder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    private static final class RankShopHolder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }
}

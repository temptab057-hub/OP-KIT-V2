# OPKITS V1 — Paper Plugin

Commands:
- `/kit` — opens the kit selection GUI.
- `/rankshop` — opens the economy rank shop.

## Rank shop prices
- VIP — 1,000,000
- VIP+ — 5,000,000
- MVP — 50,000,000
- MVP+ — 100,000,000
- MVP++ — 250,000,000
- SUPREME — 600,000,000

## Requirements
- Paper 1.21.4
- Java 21
- Vault
- An economy plugin hooked into Vault (for example EssentialsX)
- LuckPerms recommended for rank assignment

## Build the JAR
Run `gradle build` with Gradle installed. The output JAR is deliberately named **`realfile.jar`** and will be inside `build/libs/`.

## Install
1. Build the project first; this ZIP is source code, not an installable plugin.
2. Copy `build/libs/realfile.jar` into your server's `plugins/` folder.
3. Install Vault, an economy plugin, and LuckPerms.
4. Restart the server, then use `/kit` or `/rankshop`.

The plugin will create its settings folder at `plugins/OPKITS/`.

## LuckPerms configuration
The default purchase command uses `lp user %player% parent set %group%`. Create these groups first: `vip`, `vipplus`, `mvp`, `mvpplus`, `mvpplusplus`, and `supreme`. The `parent set` command replaces the player's primary parent group. Change `rankshop.purchase-commands` in `plugins/OPKITS/config.yml` if your rank setup differs.

Rank shop prices and kit settings are configurable in `plugins/OPKITS/config.yml`. Existing permission nodes retain the `nubaytkits.*` prefix for compatibility with the included configuration.
